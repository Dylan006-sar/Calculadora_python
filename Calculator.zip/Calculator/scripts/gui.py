#GUI lo que se ve
from colorama import init, Fore, Back, Style
init(autoreset=True)
print(Fore.RED + Style.BRIGHT +  "#######################\n" + Fore.WHITE + "\n    <Calculadora>\n" + Fore.RED + "\n#######################\n" + Fore.GREEN + "Escribe 1 de estas operaciones: + - * / " + "\n######################################")