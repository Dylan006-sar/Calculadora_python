#app principal o que ejecuta todo
import gui
import interno